print("Package import in progress ...")
import sys
from getpass import getpass
from cryptography.fernet import Fernet
from selenium import webdriver
from bs4 import BeautifulSoup as bs
import pandas as pd
from selenium.common.exceptions import NoSuchElementException
import time
import datetime
from os import path
from itertools import islice
import yaml
import numpy as np
# key=''
print("Package import is completed\n\n")


class web_stuff(object):
    def command_checker(self):
        arg_len = len(sys.argv)
        if arg_len == 1:
            return ("Wrong command used,following is the usage :\npython test_file.py update_SSO\npython test_file.py callbacks\npython test_file.py run")
        elif arg_len == 2 and sys.argv[1] in ['update_SSO', 'callbacks', 'verify_SSO', 'run']:
            return sys.argv[1]
        else:
            return "Invalid arguments passed,just run 'python test_file.py' for help"

    def set_key(self):
        key = Fernet.generate_key()
        with open("file_.bin", "wb") as fp:
            fp.write(key)
        return

    def get_key(self):
        with open("file_.bin", "rb") as fp:
            for line in fp:
                key = line
        return key

    def get_uname(self):
        with open('sso_email.txt', 'r') as fp:
            for line in fp:
                return line


    def get_password(self):
        cipher_suite = Fernet(self.get_key())
        with open('sso_details.bin', 'rb') as fileobject:
            for line in fileobject:
                encryptedpwd = line
        uncipher_text = cipher_suite.decrypt(encryptedpwd)
        plain_text_encryptedpassword = bytes(uncipher_text).decode("utf-8")  # convert to string
        return plain_text_encryptedpassword

    def update_SSO(self):
        self.set_key()
        cipher_suite = Fernet(self.get_key())
        plain_uname = input("Enter SSO email :")
        ciphered_upasswd = cipher_suite.encrypt(bytes(getpass("Enter you password: "), encoding='utf8'))
        with open('sso_details.bin', 'wb') as file_object:
            file_object.write(ciphered_upasswd)
        with open('sso_email.txt', 'w') as fp:
            fp.write(plain_uname)
        return "Password is updated successfully,use verify_SSO option to validate your credentials !"

    def verify_SSO(self):
        self.login_(self.get_password())
        return

    def login_(self, upasswd):
        print(upasswd)
        print(self.get_uname())
        usernameId = 'sso_username'  # From Login Page's URL
        passwordId = 'ssopassword'
        driver = webdriver.Chrome(executable_path='./chromedriver')
        driver.get("https://oracle.com/webapps/redirect/signon")
        try:
            driver.find_element_by_id(usernameId).send_keys(self.get_uname())
            driver.find_element_by_id(passwordId).send_keys(upasswd)
            driver.find_element_by_xpath("//div[@class='cb41w4']//input[@type='button']").click()
        except  NoSuchElementException as exception:
            print("Element is not found in the page ,here are full error details :\n")
            print(exception)
            print("Validate your VPN connection is entact,please check with dasari.pranaya.manish.raj@oracle.com")
            driver.quit()
            time.sleep(10)
        return



class URL_loader(web_stuff):
    def __init__(self):
        pass

        self.driver = webdriver.Chrome(executable_path='./chromedriver')
        self.driver.get("https://oracle.com/webapps/redirect/signon")
        self.usernameId = 'sso_username'
        self.passwordId = 'ssopassword'
        try:
            self.driver.find_element_by_id(self.usernameId).send_keys(web_stuff.get_uname(self))
            self.driver.find_element_by_id(self.passwordId).send_keys(web_stuff.get_password(self))
            self.driver.find_element_by_xpath("//div[@class='cb41w4']//input[@type='button']").click()
        except NoSuchElementException as exception:
            print("Element is not found in the page ,here are full error details :\n")
            print(exception)
            print("Validate if your VPN connection is entact,please check with d****j@oracle.com")
            self.driver.quit()


    def logic_function_caller(self,url_):
        #print('In logic_function_caller \n\n',url_)
        conf = yaml.full_load(open('url_details.yml'))
        #print(conf['callbacks'].values())
        #print('\n\n\n\n\n\n')
        print('*'*75,'\n','*'*75)
        if url_ in conf['callbacks'].values():
            print('URL is matched,calling call_back function now ..')
            self.call_back(url_)
        else:
            print('Code for other sections is not yet written')


    def call_back(self, url_):
        print("In callbacks")
        url1_=url_[-7:]+'.html'
        print(url1_)
        if path.isfile(url1_):
            #print("File Exists")
            data_frame_ = pd.read_html(url1_)
            if 'Sev' in data_frame_[-1].columns:
                data_frame_[-1].rename(columns={'Sev': 'Severity'}, inplace=True)
            if 'Untouched' in data_frame_[-1].columns:
                data_frame_[-1].rename(columns={'Untouched': 'Untouched Hours'}, inplace=True)
            if np.where(data_frame_[-1]['Severity'].astype(int) == 1):
                k = data_frame_[-1].iloc[np.where(data_frame_[-1]['Severity'].astype(int) == 1)][['RFC#', 'Untouched Hours']]
                k1 = k.values.tolist()
                for i in range(len(k1)):
                    print('We have SEV-1 RFC ' + k1[i][0] + ' untouched since ' + k1[i][1][3:] + ' hours')

            if np.where(data_frame_[-1]['Severity'].astype(int) == 2):
                k=data_frame_[-1].iloc[np.where(data_frame_[-1]['Severity'].astype(int) == 2)][['RFC#', 'Untouched Hours']]
                k1 = k.values.tolist()
                for i in range(len(k1)):
                    print('We have SEV-2 RFC ' + k1[i][0] + ' untouched since ' + k1[i][1][3:] + ' hours')
        else:
            print("File doesn't exists")


    def html_creator(self, source, file_name):
        html_ = bs(source, "html.parser")
        with open(file_name, 'w+', encoding="utf-8") as fh:
            fh.write(str(html_))
        return path.isfile(file_name)


    def TS_list_and_URL_list_generator(self, url_):
        # print(url_)
        tmp_list2 = []
        list_of_all_urls = []
        tmp_list = []
        list_of_all_Time_stamps_ = []
        high_limit_in_minutes = 20
        start_systime = datetime.datetime.now()
        for i in url_:
            cnt = 0
            # print('this is values of TS :' ,i[0])
            # Code_begin for making list_of_all_Time_stamps_
            while (True):
                if (cnt == int(high_limit_in_minutes / int(i[1]))):
                    break
                else:
                    tmp_list.append((start_systime + datetime.timedelta(minutes=(i[1] * cnt))).strftime('%Y-%m-%d %H:%M'))
                cnt = cnt + 1
            list_of_all_Time_stamps_.append(tmp_list)
            tmp_list = []
            # Code end for making list_of_all_Time_stamps_

            # #Code_begin for making list_of_all_urls
            if len(i[0]) == 1:
                list_of_all_urls.append(list(i[0][0]))
            else:
                for j in range(len(i[0])):
                    # print(i[0][j])
                    tmp_list2 = tmp_list2 + list(i[0][j])
                list_of_all_urls.append(tmp_list2)
            ##Code_End for making list_of_all_urls

        #print('ALL URLS LIST -->', list_of_all_urls)
        print('List of all TS :')
        for i in range(len(list_of_all_Time_stamps_)):
            print("new TS ")
            for j in range(len(list_of_all_Time_stamps_[i])):
                print(list_of_all_Time_stamps_[i][j])

        return list_of_all_urls,list_of_all_Time_stamps_,start_systime,high_limit_in_minutes



    def f_url_loader(self, url_):
        #print(url_)
        k=self.TS_list_and_URL_list_generator(url_)
        #print("All Urls :",k[0])
        url_len_list = []
        for i in range(len(k[0])):
            url_len_list.append(len(k[0][i]))
            for j in range(len(k[0][i])):
                #print(k[0][i][j])
                self.driver.execute_script("window.open(" + "'" + k[0][i][j] + "'" + ");")
                if (self.html_creator(self.driver.page_source, k[0][i][j][-7:] + '.html') == True):
                    print(k[0][i][j][-7:] + ".html file got created successfully")


        #code begin for making window handle values
        tmp=self.driver.window_handles
        tmp.reverse()
        customized_handles=tmp[:-1] #Removing LoginPage's handle
        customized_handless=iter(customized_handles)
        final_customezied_handles=[list(islice(customized_handless,elm)) for elm in url_len_list]
        #print("\n\n\nFinal customized handle list is: ",final_customezied_handles)
        #code end for making window handle value



        ##Code begin for main logic
        #print('\n\n\n',k[2],k[3])

        #print("Stored TS list :",k[1])
        print("\n\n\n")
        end_time=(k[2]+datetime.timedelta(minutes=(k[3]))).strftime('%Y-%m-%d %H:%M')

        while (True):
            #print("In Loop")
            current_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M')
            #print("\n\nCurrent TS,before loop start",current_time)
            if(current_time == end_time):
                #print("Value of current TS:", current_time)
                #print("Value of end_time:", end_time)
                break
            if(current_time in [elem for sublist in k[1] for elem in sublist]):
                for i in range(len(k[1])):
                    if current_time in k[1][i]:
                        for j in range(len(final_customezied_handles[i])):
                            self.driver.switch_to.window(final_customezied_handles[i][j])
                            self.driver.refresh()
                            if (self.html_creator(self.driver.page_source, k[0][i][j][-7:] + '.html') == True):
                                #print(k[0][i][j][-7:] + ".html file got updated successfully")
                                pass
                            else:
                                print("There some problem creating html file,please get this checked")
                                exit()
                            self.logic_function_caller(k[0][i][j])
                            #time.sleep(30)
                        #print("List Before Removal :",k[1][i])
                        k[1][i].remove(current_time)
                        #print("List After Removal :", k[1][i])

                #print("Value of current TS:",current_time)
                #print("Value of stored TS:",elem)
            else:
                pass
                #print("Value of current TS,when condition is not met:", current_time)

            time.sleep(60)

        ##Code end for main logic
