import yaml
from main_file import web_stuff,URL_loader
conf = yaml.full_load(open('url_details.yml'))

wb=web_stuff()
def main():
    k=wb.command_checker()
    if(k=="update_SSO"):
        print(wb.update_SSO())
    elif(k=="verify_SSO"):
        print(wb.verify_SSO())
    elif(k=="run"):
        ul1 = URL_loader()
        ul1.f_url_loader([[[conf['callbacks'].values()], 2],[[conf['new_section'].values(),conf['eip'].values()], 4],[[conf['analysis_pending'].values()],10]])

    else:
        print("-->", k)


if __name__=='__main__' :
    main()
